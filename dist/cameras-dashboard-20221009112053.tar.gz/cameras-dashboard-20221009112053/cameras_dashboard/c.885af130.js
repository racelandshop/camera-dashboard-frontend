import{am as a,ao as o,aw as s}from"./c.fc0bbf07.js";const t=a({type:o(),view_layout:s()});export{t as b};
