const e=(e,t,l)=>e.callService(t.split(".",1)[0],"set_value",{value:l,entity_id:t});export{e as s};
