import{_ as r,r as c,n as o}from"./main-d07cb663.js";import{C as s,s as a}from"./c.6da20489.js";r([o("ha-checkbox")],(function(r,o){return{F:class extends o{constructor(...c){super(...c),r(this)}},d:[{kind:"field",static:!0,key:"styles",value:()=>[a,c`
      :host {
        --mdc-radio-unchecked-color: var(--primary-text-color);
        --mdc-theme-secondary: var(--primary-color);
      }
    `]}]}}),s);
