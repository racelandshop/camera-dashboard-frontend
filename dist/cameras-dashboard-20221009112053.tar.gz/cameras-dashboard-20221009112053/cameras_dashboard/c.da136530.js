const n=n=>n.callApi("GET","config/config_entries/entry");export{n as g};
