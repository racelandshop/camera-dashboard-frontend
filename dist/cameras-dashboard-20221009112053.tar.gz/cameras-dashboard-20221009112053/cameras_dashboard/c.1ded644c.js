const t=(t,a)=>"https://store.automacaoraceland.pt/";export{t as d};
