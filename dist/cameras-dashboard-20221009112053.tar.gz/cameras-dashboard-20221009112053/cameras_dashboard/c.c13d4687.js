const s=async(s,n)=>new Promise((o=>{const c=n(s,(s=>{c(),o(s)}))}));export{s};
