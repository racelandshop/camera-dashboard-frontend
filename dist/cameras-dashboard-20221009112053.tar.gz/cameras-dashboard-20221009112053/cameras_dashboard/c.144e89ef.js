import{r,s as t}from"./c.655d6539.js";function e(e,n){r(2,arguments);var i=t(e),o=t(n);return i.getTime()===o.getTime()}function n(t){return r(1,arguments),e(t,Date.now())}export{n as i};
