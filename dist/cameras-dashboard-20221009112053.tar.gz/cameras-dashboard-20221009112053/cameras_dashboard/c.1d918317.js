const a="number",e=(a,e,c,l)=>{a.callService("alarm_control_panel",`alarm_${c}`,{entity_id:e,code:l})};export{a as F,e as c};
